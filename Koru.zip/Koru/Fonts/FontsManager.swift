//
//  FontsManager.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct FontsManager {
    
    struct DMSerif {
        static let regular = "DMSerifDisplay-Regular"
        static let italic = "DMSerifDisplay-Italic"

    }
    
    struct Syne {
        static let syne = "Syne"
        static let bold = "Syne-Bold"
        static let medium = "Syne-Medium"
        static let regular = "Syne-Regular"
        static let semibold = "Syne-SemiBold"

    }
}
