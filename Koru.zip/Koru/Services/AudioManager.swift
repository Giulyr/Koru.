//
//  AudioManager.swift
//  Koru
//
//  Created by Jarvis on 14/06/22.
//

import Foundation
import AVFoundation


class AudioManager: NSObject, AVAudioPlayerDelegate {
    
    private var audioPlayersDict: [String: AVAudioPlayer] = [:]
    
    public func playSound(fileNamed: String, with fileExtension: String, looped: Bool, withKey: String) {
        guard let soundUrl = Bundle.main.url(forResource: fileNamed, withExtension: fileExtension) else {
            return
        }
        do {
            try AVAudioSession.sharedInstance().setCategory(.soloAmbient)
            try AVAudioSession.sharedInstance().setActive(true)
            
            let audioPlayer = try AVAudioPlayer(contentsOf: soundUrl)
            if looped {
                audioPlayer.numberOfLoops = -1
            }
            audioPlayer.play()
            audioPlayer.delegate = self
            audioPlayersDict[withKey] = audioPlayer
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
    internal func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        guard let key = audioPlayersDict.first(where: { $1 == player})?.key else {
            return
        }
        audioPlayersDict.removeValue(forKey: key)
    }

    public func changeVolume(ofPlayerWithKey: String, to volume: Float) {
        guard let audioPlayer = audioPlayersDict[ofPlayerWithKey] else {
            return
        }
        audioPlayer.volume = volume
    }
    
    public func getVolume(ofPlayerWithKey key: String) -> Float {
        guard let audioPlayer = audioPlayersDict[key] else {
            return -1
        }
        return audioPlayer.volume
    }
    
    public func stopPlayer(withKey: String) {
        guard let audioPlayer = audioPlayersDict[withKey] else {
            return
        }
        audioPlayer.stop()
    }
    
    public func isPlaying(playerWithKey key: String) -> Bool {
        guard let audioPlayer = audioPlayersDict[key] else {
            return false
        }
        
        return audioPlayer.isPlaying
    }
        
    
}
