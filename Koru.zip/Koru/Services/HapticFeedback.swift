//
//  HapticFeedback.swift
//  Koru
//
//  Created by Jarvis on 15/06/22.
//

import Foundation
import CoreHaptics

class CustomHaptics {
    var hapticEngine: CHHapticEngine?
    init() {
        do {
            try self.hapticEngine = CHHapticEngine()
        }
        catch {
            print("Failed to initialize haptic engine: \(error)")
        }
        
        
        guard let hapticEngine = hapticEngine else {
            
#if targetEnvironment(simulator)
            return
#else
            print("Could not initialize haptic engine")
            return
#endif
        }
        do {
            try hapticEngine.start()
        }
        catch {
            print("Failed to start haptic engine")
        }
        
    }
    func playHaptic(intensity: Float, sharpness: Float, duration: TimeInterval) {
        guard let hapticEngine = hapticEngine else {
            
#if targetEnvironment(simulator)
            return
#else
            print("Could not retrieve haptic engine")
            return
#endif
            
        }
        
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity)
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
        let continuousEvent = CHHapticEvent(eventType: .hapticContinuous,
                                            parameters: [intensity, sharpness],
                                            relativeTime: 0,
                                            duration: duration)
        
        do {
            // Create a pattern from the continuous haptic event.
            let pattern = try CHHapticPattern(events: [continuousEvent], parameters: [])
            
            // Create a player from the continuous haptic pattern.
            let continuousPlayer = try hapticEngine.makeAdvancedPlayer(with: pattern)
            try continuousPlayer.start(atTime: CHHapticTimeImmediate)
        } catch let error {
            print("Pattern Player Creation Error: \(error)")
        }
    }
    
}

