//
//  limit.swift
//  Koru
//
//  Created by Mirko Pietro Leone on 06/06/22.
//

import SwiftUI
//
//class TextFieldManager: ObservableObject {
//    
//    let characterLimit = 20
//
//    @Published var userInput = "" {
//            didSet {
//if userInput.count > characterLimit {
//                    
//                    userInput = String(userInput.prefix(characterLimit))
//                        return
//                    
//                }
//            }
//        }
//    
//}


class TextBindingManager: ObservableObject {
   @Published var text = "" {
       didSet {
           if text.count > characterLimit && oldValue.count <= characterLimit {
               text = oldValue
           }
       }
   }
   let characterLimit: Int

   init(limit: Int = 1){
       characterLimit = limit
   }
}
