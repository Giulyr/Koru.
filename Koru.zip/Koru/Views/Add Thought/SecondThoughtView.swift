//
//  SecondThoughtView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct SecondThoughtView: View {
    @EnvironmentObject var appState : AppState
    @Environment(\.presentationMode) var presentationMode
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)
    @Binding var context : String
    @Binding var thought : String
    @Binding var feel : String
    var body: some View {
        
        ZStack(alignment: .top) {
            
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            
            VStack(){
           
                   
                Image("2-vector-newthought")
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 50)
            
            VStack(alignment: .leading){
                Text ("What’s your thought?")
                    .font(.custom(FontsManager.DMSerif.regular, size:25))

//  MARK: TEXTEDITOR CON PLACEHOLDER
                VStack(alignment: .trailing){
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 8, style: .continuous)
                        .fill(Color.white)
                    
                    if thought.isEmpty {
                        Text("What are you thinking about?")
                            .font(.custom("Syne", size: 16))
                            .foregroundColor(Color(UIColor.placeholderText))
                            .padding(.top, 12)
                            .padding(.leading, 8)

                    }
                    
                    TextEditor(text: $thought)
                        .font(.custom("Syne", size: 16))
                        .limitInputLength(value: $context, length: 220)
                        .disableAutocorrection(true)
                        .padding(.leading, 4)
                    
                }
                .frame(width:textFieldwidth, height: 109)
                .cornerRadius(15)
                //    :TextEditor
                CounterView(text: $thought)
                }
            }
            .padding(.top, 40)

            }
            
            .navigationBarTitle("New Thought", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                
                NavigationLink(destination: ThirdThoughtView(thought: $thought, context: $context, feel: $feel).environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !thought.isEmpty ? Color("CustomBlack") : .secondary
                        )
                }
                .disabled(thought.isEmpty)
             }) //: NAVIGATION BAR ITEMS
            
        }  .onTapGesture {
            self.hideKeyboard()

        }//: ZStack
    } //: View
} //: Struct

struct SecondThoughtView_Previews: PreviewProvider {
    static var previews: some View {
        SecondThoughtView(context: .constant(""), thought: .constant(""), feel: .constant("")).environmentObject(AppState())
    }
}
