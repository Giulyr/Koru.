//
//  FirstAnalyses.swift
//  Koru
//
//  Created by Mirko Pietro Leone on 08/06/22.
//

import SwiftUI

struct FirstAnalyses: View {
    var body: some View {
    
    }
}

struct FirstAnalyses_Previews: PreviewProvider {
    static var previews: some View {
        FirstAnalyses()
    }
}
