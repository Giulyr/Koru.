//
//  AddThoughtView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//
import SwiftUI


struct AddThoughtView: View {
    @EnvironmentObject var appState : AppState
    @State var context : String = ""
    @State var thought : String = ""
    @State var feel : String = ""
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)
    let pallaH : CGFloat = (UIScreen.main.bounds.size.height * 0.231)
    init() {
        UITextView.appearance().backgroundColor = .clear
    }
    
    @Environment(\.presentationMode) var presentationMode
    
    
    var body: some View {
        NavigationView{
            ZStack (alignment: .top){
                //MARK: - BACKGROUND
                Color("CustomWhite")
                    .ignoresSafeArea(.all, edges: .all)
                //: -Background
                
                VStack {
//                              Text ("\(textFieldwidth)")
                    Image("1-vector-newthought")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 130)
                        .padding(.top, 50)
                    
                    VStack(alignment: .leading){
                    Text ("In what context are you?")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                        .padding(.top, 40)
                        
                    //               MARK: TEXTEDITOR CON PLACEHOLDER
                        VStack(alignment: .trailing){
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color.white)
                        
                        if context.isEmpty {
                            Text("Where are you? Who is with you?")
                                .font(.custom("Syne", size: 16))
                                .foregroundColor(Color(UIColor.placeholderText))
                                .padding(.top, 12)
                                .padding(.leading, 8)
                        }
               
                        
                        TextEditor(text: $context)
                            .font(.custom("Syne", size: 16))
                            .limitInputLength(value: $context, length: 220)
                            .disableAutocorrection(true)
                            .padding(.leading, 4)
                        
                    }
                    .frame(width: textFieldwidth, height: 109)
                    .cornerRadius(15)
                        
                        CounterView(text: $context)
                        }
                    //    :TextEditor
                    }
                    
                }
                .navigationBarTitle("New Thought", displayMode: .inline)
                
                
                
                //MARK: - NAVIGATION BAR ITEMS
                .navigationBarItems(leading:
                                        HStack {
                    Button{
                        print("Back tapped")
                        withAnimation(){
                            appState.viewState = .mainView
                        }
                    } label : {
                        
                        Image("BackButton")
                            .resizable()
                            .scaledToFit()
                    }
                }, trailing:
                HStack {
                    
                    NavigationLink(destination: SecondThoughtView(context: $context, thought: $thought, feel: $feel).environmentObject(appState).navigationBarBackButtonHidden(true)){
                        Text("Next")
                            .font(.custom(FontsManager.Syne.regular, size:17))
                            .foregroundColor(
                                !context.isEmpty ? Color("CustomBlack") : .secondary
                            )
                    }
                    .disabled(context.isEmpty)
                   
                }) //: NAVIGATION BAR ITEMS
                
            }
        } .onTapGesture {
            self.hideKeyboard()
        }//: ZStack
    }
  //: View
} //: Struct

struct AddThoughtView_Previews: PreviewProvider {
    static var previews: some View {
        AddThoughtView().preferredColorScheme(.light).environmentObject(AppState())
    }
}
