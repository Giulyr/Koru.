//
//  FourthView.swift
//  Koru
//
//  Created by Giulls on 07/06/22.
//

import SwiftUI
import CoreData
struct FourthThoughtView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appState : AppState
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @Environment(\.managedObjectContext) private var viewContext
    @Binding var thought : String
    @Binding var context : String
    @Binding var feel : String
    @Binding var feelknots : [String : String]
    @State var date : Date = Date.now
    @State var isFinished = false
 
    var bool : Bool = false

    init(thought : Binding<String>, context : Binding <String>, feel : Binding <String>, feelknots : Binding<[String : String]>){
     
        self._feel = feel
        self._context = context
        self._thought = thought
        self._feelknots = feelknots
    }
//    
    var body: some View {
        
        ZStack {
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            
            VStack {
                
                //                MARK: - SPACE FOR LINE
                Image(feelknots[feel]!)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 50)
                
                //                MARK: - TEXT
                ScrollView {
                    VStack (alignment: .leading, spacing: 40){
                        
                        VStack (alignment: .leading, spacing: 10){
                            
                            Text("Where you were")
                                .font(.custom(FontsManager.Syne.bold, size:20))
                            
                            Text("\(context)")
                                .font(.custom(FontsManager.Syne.medium, size:18))
                                .multilineTextAlignment(.leading)
                                .foregroundColor(Color("CustomGray"))
                            
                        } //: VStack
                        
                        VStack (alignment: .leading, spacing: 10) {
                            
                            Text("Your thought")
                                .font(.custom(FontsManager.Syne.bold, size:20))
                            
                            Text("\(thought)")
                                .font(.custom(FontsManager.Syne.medium, size:18))
                                .multilineTextAlignment(.leading)
                                .foregroundColor(Color("CustomGray"))
                        } //: VStack
                        .frame(minHeight: 250, alignment: .top)
                        
                        
                        
                    } //: VStack
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                    .padding(.top, 50)
                    
                    
                    //MARK: - BUTTON COLLECT
                    Button {
                        print("Feel \(feel)")
                        addNewIntrusive(context: context, thought: thought, feel: feel, date: Date.now)
                        withAnimation(){
                            appState.viewState = .mainView
                        }
                    } label: {
                        ButtonView (text: "Collect")
                    }.padding(.top, 35)
                }
            } //: VStack
            
            .navigationBarTitle("Overview", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }) //: NAVIGATION BAR ITEMS
            NavigationLink(destination: ManagerView().environmentObject(appState).navigationBarHidden(true), isActive: $isFinished){
                EmptyView()
            }
        } //: ZStack
    } //: View
    
  
    //    MARK: ADD FUNC
    func addNewIntrusive(context: String, thought: String, feel : String, date: Date) {
        let newIntrusive = Intrusive(context: viewContext)
        newIntrusive.id = UUID()
        newIntrusive.context = context
        newIntrusive.thought = thought
        newIntrusive.feel = feel
        newIntrusive.date = date
        print("Feel")
        PersistenceManager.shared.saveContext()
    }
    
} //: Struct




struct FourthThoughtView_Previews: PreviewProvider {
    static var previews: some View {
        FourthThoughtView(thought: .constant("Example"), context: .constant("Example"), feel: .constant("Angry"),feelknots: .constant(["": ""])).environmentObject(AppState())
    }
}
