//
//  ThirdThoughtView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct ThirdThoughtView: View {
    @EnvironmentObject var appState : AppState
    
    @Environment(\.presentationMode) var presentationMode
    
    @Environment(\.managedObjectContext) private var viewContext
    
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)

    @Binding var thought : String
    @Binding var context : String
    @Binding var feel : String
    @State var ToSaveFeel  = ["Afraid", "Angry", "Anxious", "Disgusted", "Guilty", "Sad"]
    @State var  feelknots : [String : String] = ["Afraid": "4-thought-afraid","Angry" : "4-thought-angry", "Anxious" : "4-thought-anxious", "Disgusted" : "4-thought-disgusted", "Guilty" : "4-thought-guilty", "Sad" : "4-thought-sad"
    ]
    
    @State var animation : Bool = false
    @State var animation1 : Bool = false
    @State var animation2 : Bool = false
    @State var animation3 : Bool = false
    @State var animation4 : Bool = false
    @State var animation5 : Bool = false
    
    
    var body: some View {
        
        ZStack (alignment: .topLeading){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            
            
            
            VStack {
                if feel == "" {
                    Image("3-vector-newthought")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 130)
                        .padding(.top, 50)
                }
                else {
                    Image(feelknots[feel]!)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 130)
                        .padding(.top, 50)
                }
             
                
                //                MARK: VSTACK TESTO + TUTTI FEEL
                
           
                VStack (alignment: .leading, spacing: 40){
                    Text ("How do you feel?")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                        .padding(.top, 20)
                        .padding(.horizontal, 9)
                    
                    VStack(spacing: 50){
                    
                    //                  MARK: HSTACK A FEEL
                    HStack  (spacing: 25){
                        
                        Button() {
                            feel = feel == ToSaveFeel[0] ? "" : ToSaveFeel[0]
                            animation.toggle()
                            animation1 = false
                            animation2 = false
                            animation3 = false
                            animation4 = false
                            animation5 = false
                            
                        } label: {
                            VStack{
                                Image("Bigafraid")
                                Text("Afraid")
                                    .font(animation ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16))
                                    .foregroundColor(animation ?Color("CustomBlack") : Color("CustomGray")).underline(animation)
                                    .frame (width : 106)
                                
                                
                            }
                        }
                        
                        
                        Button() {
                            feel = feel == ToSaveFeel[1] ? "" : ToSaveFeel[1]
                            print(feel)
                            animation1.toggle()
                            
                            animation = false
                            animation2 = false
                            animation3 = false
                            animation4 = false
                            animation5 = false
                        } label: {
                            VStack{
                                Image("Bigangry")
                                Text("Angry")
                                    .font(animation1 ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16))                                    .foregroundColor(animation1 ? Color("CustomBlack") : Color("CustomGray")).underline(animation1)
                                    .frame(width : 106)
                                
                            }
                        }
                        
                        Button() {
                            feel = feel == ToSaveFeel[2] ? "" : ToSaveFeel[2]
                            print(feel)
                            
                            animation2.toggle()
                            animation = false
                            animation1 = false
                            animation3 = false
                            animation4 = false
                            animation5 = false
                        } label: {
                            VStack{
                                Image("Biganxious")
                                Text("Anxious")
                                    .font(animation2 ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16))                                    .foregroundColor(animation2 ?Color("CustomBlack") : Color("CustomGray")).underline(animation2)
                                    .frame(width : 106)
                            }
                        }
                    }
                    
                    //                    MARK: HSTACK LAST FEEL
                    
                        HStack(spacing: 25){
                        
                        Button() {
                            feel = feel == ToSaveFeel[3] ? "" : ToSaveFeel[3]
                            print(feel)
                            animation3.toggle()
                            animation1 = false
                            animation2 = false
                            animation = false
                            animation4 = false
                            animation5 = false
                            
                        } label: {
                            VStack{
                                Image("Bigdisgusted")
                                Text("Disgusted")
                                    .foregroundColor(animation3 ? Color("CustomBlack") : Color("CustomGray"))
                                    .font(animation3 ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16)).underline(animation3)
                                    .frame (width : 106)
                                
                            }
                        }
                        
                        Button() {
                            feel = feel == ToSaveFeel[4] ? "" : ToSaveFeel[4]
                            print(feel)
                            animation4.toggle()
                            animation1 = false
                            animation2 = false
                            animation3 = false
                            animation = false
                            animation5 = false
                            
                        } label: {
                            VStack{
                                Image("Bigguilty")
                                Text("Guilty")
                                    .font(animation4 ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16))
                                    .foregroundColor(animation4 ? Color("CustomBlack") : Color("CustomGray")).underline(animation4)
                                    .frame (width : 106)
                            }
                        }
                     
                        
                        Button() {
                            feel = feel == ToSaveFeel[5] ? "" : ToSaveFeel[5]
                            print(feel)
                            animation5.toggle()
                            
                            animation1 = false
                            animation2 = false
                            animation3 = false
                            animation4 = false
                            animation = false
                            
                        } label: {
                            VStack{
                                Image("Bigsad")
                                Text("Sad")
                                    .font(animation5 ? .custom(FontsManager.Syne.semibold, size:16) : .custom(FontsManager.Syne.regular, size:16))
                                    .foregroundColor(animation5 ? Color("CustomBlack") : Color("CustomGray")).underline(animation5)
                                    .frame (width : 106)
                            }
                        }
                    }
                    
                }
              
                .frame(width: UIScreen.main.bounds.width - 16)
                } .padding(.top, 20)
                 
            }
            
            .frame(maxWidth: .infinity, alignment: .leading)
            
            //: VStack
            
            .navigationBarTitle("New Thought", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    feel = ""
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                NavigationLink(destination: FourthThoughtView( thought: $thought, context: $context, feel: $feel, feelknots: $feelknots).environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !feel.isEmpty ? Color("CustomBlack") : .secondary
                        )
                }
                
            }) //: NAVIGATION BAR ITEMS
            
            
        } .onTapGesture {
            self.hideKeyboard()
        } //: VStack
    }//: ZStack
   
} //: View
//: Struct




struct ThirdThoughtView_Previews: PreviewProvider {
    static var previews: some View {
        ThirdThoughtView(thought: .constant(""), context: .constant(""), feel: .constant("")).environmentObject(AppState())
    }
}

