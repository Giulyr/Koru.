//
//  OnboardingView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//


import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var appState : AppState

    @AppStorage("onboardingViewShown")
    var onboardingViewShown : Bool = false
    @State var selectedView = 1

    var body: some View {
        NavigationView {
            
            ZStack {
//MARK: - BACKGROUND
                Color("CustomWhite")
                    .ignoresSafeArea(.all, edges: .all)
                
//MARK: - TABVIEW
                
                TabView(selection: $selectedView) {
                    
                    FirstView(selection: $selectedView).tag(1)
                    
                    SecondView(selection: $selectedView).tag(2)
                    
                    ThirdView(selection: $selectedView).tag(3)
                    
                } //: -TabView
                
//MARK: TOOL BAR ELEMENTS
                
                .toolbar {
                  
                    ToolbarItem(placement: .navigationBarTrailing){

//MARK: - SKIP BUTTON
                        if selectedView != 3 {
                        Button{
                            print ("Skip tapped")
                        } label: {
                            NavigationLink(destination: MainView().environmentObject(appState).navigationBarHidden(true)) {
                                Text("Skip")
                                    .font(.custom(FontsManager.Syne.semibold, size:17))
                                .foregroundColor(Color("CustomBlack"))

                            }.onAppear{
                                UserDefaults.standard.isOnboardingCompleted = true
                            }
                        }
                        }//: SKIP
                    }
                    ToolbarItem(placement: .navigationBarLeading){
                        
//MARK: - BACK ARROW
                        Button {
                            withAnimation{
                            if selectedView > 1 {
                                selectedView -= 1
                            }}
                        } label: {
                            if selectedView > 1{
                                
                                    Image("BackButton")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 27, height: 21.97)
                            }
                            }
                    }
                
                } //: -Tool Bar elements
            }
        }
        .ignoresSafeArea()
        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
        .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
        .navigationBarHidden(false)
    }
}


struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView().environmentObject(AppState())
    }
}
