//
//  ThirdView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct ThirdView: View {
//MARK: - PROPERTY
    @EnvironmentObject var appState : AppState
    @Binding var selection : Int

    
    var body: some View {
        
        ZStack {
            
            //MARK: - BACKGROUND
                            Color("CustomWhite")
                                .ignoresSafeArea(.all, edges: .all)
            GeometryReader{ geometry in
                VStack{
                    VStack{
                        Image("ThirdLine")
                            .resizable()
                            .scaledToFill()
                    } .frame(width: geometry.size.width * 1, height: geometry.size.height * 0.2, alignment: .top
                    )
                    
                VStack (spacing: 20){
                    
                    Text("You are Koru")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                    
                    Text("Take your time: choose when to receive the daily notification to focus on the analysis phase.")
                        .multilineTextAlignment(.center)
                        .font(.custom(FontsManager.Syne.medium, size:18))
                        .foregroundColor(Color("CustomGray"))
                }.frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.5, alignment: .bottom)
            VStack{
                
                Button (action: {
                    print("Next tapped")
                }, label: {
                    NavigationLink(destination: MainView().environmentObject(appState).navigationBarHidden(true)) {
                    ButtonView (text: "Start")
                }
            })
              
            }.frame(width: geometry.size.width * 1, height: geometry.size.height * 0.15, alignment: .bottom)
                
                }
                    
            }
            
        } //: ZStack
        
        .onAppear(perform: {
            UserDefaults.standard.isOnboardingCompleted = true
        })
    } //: View
} //: Struct

struct ThirdView_Previews: PreviewProvider {
    @State static var selection = 3
    static var previews: some View {
        ThirdView(selection: $selection).environmentObject(AppState())
    }
}
