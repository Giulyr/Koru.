//
//  FirstView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct FirstView: View {
//MARK: - PROPERTY
    
    @Binding var selection : Int
    
    var body: some View {
        
        ZStack(alignment: .top){
            //MARK: - BACKGROUND
                            Color("CustomWhite")
                                .ignoresSafeArea(.all, edges: .all)
            
            GeometryReader{ geometry in
                VStack{
                    VStack{
                        Image("FirstLine")
                            .resizable()
                            .scaledToFill()
                    } .frame(width: geometry.size.width * 1, height: geometry.size.height * 0.2, alignment: .top
                    )
                    
                VStack (spacing: 20){
                    
                    Text("The path of life")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                    
                    Text("The path of life is not always linear. Each one of us, our thoughts, our habits, change and evolve with it.")
                        .multilineTextAlignment(.center)
                        .font(.custom(FontsManager.Syne.medium, size:18))
                        .foregroundColor(Color("CustomGray"))
                }.frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.5, alignment: .bottom)
            VStack{
                
                Button (action: {
                    withAnimation {
                        selection = 2
                    }
                }, label: {
                    
                    Text ("Next")
                        .font(.custom(FontsManager.Syne.semibold, size:17))
                        .foregroundColor(Color("CustomBlack"))
                        .underline()
                        .frame(width: 49, height: 24, alignment: .center)
                }) //: Button
              
            }.frame(width: geometry.size.width * 1, height: geometry.size.height * 0.15, alignment: .bottom)
                
                }
                    
            }
               
                   
            
        } //: ZStack
    } //: View
} //: Struct

struct FirstView_Previews: PreviewProvider {
    @State static var selection = 1
    static var previews: some View {
        FirstView(selection: $selection)
    }
}
