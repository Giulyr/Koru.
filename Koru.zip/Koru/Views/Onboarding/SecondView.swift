//
//  SecondView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct SecondView: View {
//MARK: - PROPERTY
    
    @Binding var selection : Int
    
    var body: some View {
        
        ZStack (alignment: .top){
            
            //MARK: - BACKGROUND
                            Color("CustomWhite")
                                .ignoresSafeArea(.all, edges: .all)
                            //: -Background
            GeometryReader{ geometry in
                VStack{
                    VStack{
                        Image("SecondLine")
                            .resizable()
                            .scaledToFill()
                    } .frame(width: geometry.size.width * 1, height: geometry.size.height * 0.2, alignment: .top
                    )
                    
                VStack (spacing: 20){
                    
                    Text("Thoughts are your destiny")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                    
                    Text("Koru helps you along this path, analyzing what your intrusive thoughts are, and initialize their resolution.")
                        .multilineTextAlignment(.center)
                        .font(.custom(FontsManager.Syne.medium, size:18))
                        .foregroundColor(Color("CustomGray"))
                }.frame(width: geometry.size.width * 0.9, height: geometry.size.height * 0.5, alignment: .bottom)
            VStack{
                
                Button (action: {
                    withAnimation {
                        selection = 3
                    }
                }, label: {
                    
                    Text ("Next")
                        .font(.custom(FontsManager.Syne.semibold, size:17))
                        .foregroundColor(Color("CustomBlack"))
                        .underline()
                        .frame(width: 49, height: 24, alignment: .center)
                }) //: Button
              
            }.frame(width: geometry.size.width * 1, height: geometry.size.height * 0.15, alignment: .bottom)
                
                }
                    
            }
        } //: ZStack
    } //: View
} //: Struct


struct SecondView_Previews: PreviewProvider {
    @State static var selection = 2
    static var previews: some View {
        SecondView(selection: $selection)
    }
}
