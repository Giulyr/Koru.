//
//  AlertFullView.swift
//  Koru
//
//  Created by Giulls on 12/06/22.
//

import SwiftUI

struct AlertFullView: View {
    @Binding var shown : Bool
    var body: some View {
        ZStack {
            //MARK: - BACKGROUND
            Color.black.opacity(0.075)
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            Spacer()
            VStack {
                VStack{
                VStack {
                    Text("It's time to investigate!")
                        .font(.custom(FontsManager.Syne.bold, size:20))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 30)
                    
                    VStack(spacing: 20) {
                        Text("""
                                Your line is full!
                                Take a moment for yourself.
                                """)
                        .font(.custom(FontsManager.Syne.medium, size:18))
                        .foregroundColor(Color("CustomGray"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        Text("""
                            Analyze one of your thoughts
                            before adding more.
                            """
                        )
                        .font(.custom(FontsManager.Syne.medium, size:18))
                        .foregroundColor(Color("CustomGray"))
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    }
                } .padding(.bottom, 30)
                      
                
                    Button {
                        self.shown.toggle()
                    } label: {
                        Text ("Got it!")
                            .font(.custom(FontsManager.Syne.semibold, size:20))
                            .foregroundColor(Color("CustomWhite"))
                            .background(
                                RoundedRectangle(cornerRadius: 13)
                                    .fill(Color("CustomBlack"))
                                    .frame(
                                        width: 271,
                                        height: 60,
                                        alignment: .center
                                    )
                            )
                    }.padding(.vertical, 30)
                }.padding(.horizontal)
                
            }
            .background(
                Capsule().strokeBorder(Color.white, lineWidth: 0)
                    .background(.white)
                    .cornerRadius(10)
                    .frame(height: 338, alignment: .center)
            )
            .frame(maxWidth: UIScreen.main.bounds.width - 60)
        }
    }
}

struct AlertFullView_Previews: PreviewProvider {
    static var previews: some View {
        AlertFullView(shown: .constant(true))
    }
}
