//
//  CognitiveCardView.swift
//  Koru
//
//  Created by Giulls on 08/06/22.
//

import SwiftUI
import UnleashSwiftUI


struct CognitiveCardView: View {
    
    let columns : [GridItem] = Array(repeating: .init(.flexible()), count: 2)
    @Binding var Num : Int 
    @State var disabled : Bool = false
    @State var selected : [Bool] = [false, false,false,false,false,false,false, false]
    @State var halfModalPresented : [Bool] = [false, false,false,false,false,false,false,false]
    @Binding var selectedErrors : [String]
    var keys : [String] = ["Mental filtering","Over-Generalization","Polarized thinking","Fallacies","Catastrophizing","Blaming","Jumping to conclusion","Emotional reasoning"]
    init(selectedErrors: Binding<[String]>, Num : Binding<Int>){
        self._selectedErrors = selectedErrors
        self._Num = Num
    }
    var body: some View {
        
        
        ZStack(alignment: .top) {

            LazyVGrid(columns: columns,spacing: 25) {
                ForEach (0..<8, id: \.self) {i in
                    ButtonCognitiveProblems(name: "\(keys[i])", Num: $Num,disabled: $disabled, selected: $selected[i], selectedErrors: $selectedErrors)                     
                }
            }
            .padding(.horizontal, 20)
            
        }
        }
    }


struct CognitiveCardView_Previews: PreviewProvider {
    static var previews: some View {
//        CognitiveCardView(selectedErrors: .constant([""]))
        AnalyzeFirst(selectedErrors: ["ciao"], feelknots: .constant(["": ""]))
    }
}
