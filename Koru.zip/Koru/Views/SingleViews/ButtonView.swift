//
//  ButtonView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct ButtonProto: Identifiable {
    var id = UUID()
    var text: String
}

struct ButtonView: View {
    
    var text: String
    
    var body: some View {
        
//MARK: - BUTTON
   
        ZStack {
            Text (text)
                        .font(.custom(FontsManager.Syne.semibold, size:20))
                        .foregroundColor(Color("CustomWhite"))
                        .frame(width: 252, height: 24, alignment: .center)
        } //: ZStack
        
            .background(
                Capsule().strokeBorder(Color.white, lineWidth: 0)
                    .background(Color("CustomBlack"))
                    .cornerRadius(13)
                    .frame(height: 60, alignment: .center)
                    .frame(minWidth: UIScreen.main.bounds.width - 60)
            )
    } //: View
} //: Struct


struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView(text: "Let's start")
    }
}
