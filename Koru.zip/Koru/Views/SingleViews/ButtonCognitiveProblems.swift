//
//  ButtonCognitiveProblems.swift
//  Koru
//
//  Created by Giulls on 08/06/22.
//

import SwiftUI
import UnleashSwiftUI

struct ButtonCognitiveProblems: View {
    var name : String
    @Binding var Num : Int
    @Binding var disabled : Bool
    
    @Binding var selected : Bool
    @State var halfModalPresented : Bool = false
    @Binding var selectedErrors : [String]
    init(name: String, Num : Binding<Int>,disabled : Binding <Bool>, selected: Binding<Bool>, selectedErrors: Binding<[String]>){
        self.name = name
        self._selected = selected
        self._selectedErrors = selectedErrors
        self._Num = Num
        self._disabled = disabled
    }
    
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button {
                selected.toggle()
               
                if selected == true {
                    Num += 1
                    if Num >= 3 {
                        disabled = true
                    }
                }
                if selected == false{
                    Num -= 1
                    disabled = false
                }
                
                
                if selectedErrors.contains(name){
                    var number = 0
                    for i in 0..<selectedErrors.count {
                        if selectedErrors[i] == name{
                            number = i
                        }
                    }
                    selectedErrors.remove(at: number)
                }else{
                    selectedErrors.append(name)
                }
                print(selectedErrors )

            } label: {
                VStack {
                    Spacer()
                    HStack {
                        Text("\(name)")
                            .multilineTextAlignment(.leading)
                            .font(.custom(FontsManager.Syne.medium, size:15))
                            .foregroundColor(Color("CustomBlack"))
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(lineWidth: 4)
                        .foregroundColor(Color("CustomBlack"))
                        .opacity(selected ? 1 : 0)
                )
            }.disabled(disabled == true && selected == false)
            Button {
                halfModalPresented = true
                print(name)
            } label: {
                Image("Info")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .foregroundColor(Color("CustomGray2"))
                    .padding(.trailing, 10)
                    .padding(.top, 10)
            }

        }
        .background(.white)
        .cornerRadius(5)
        .frame(minWidth: 80, maxWidth: 165, minHeight: 80, maxHeight: 135) //modificare questi valori per averlo nelle varie dimensioni
        .sheet(isPresented: $halfModalPresented, detents: [.medium()], showGrabber: true, scrollingExpand: false, undimmed: .large, edgeRadius: 10) {
            HalfModalView(key: name)
        }
    }
}


//struct LabelCognitiveView_Previews: PreviewProvider {
//    static var previews: some View {
//
//        ButtonCognitiveProblems(name: "placeholder", selected: .constant(false),selectedErrors: .constant([""]))
//            .previewLayout(.sizeThatFits)
//            .padding()
//        ButtonCognitiveProblems(name: "placeholder", selected: .constant(false),selectedErrors: .constant([""]))
//            .previewLayout(.sizeThatFits)
//            .padding()
//
//    }
//}
