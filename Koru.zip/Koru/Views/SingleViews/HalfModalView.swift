//
//  HalfModalView.swift
//  Koru
//
//  Created by Giulls on 13/06/22.
//

import SwiftUI

struct HalfModalView: View {
    @Environment(\.presentationMode) var presentationMode
    var key : String
    let cognitiveErrors : [String : String] = [
        "Mental filtering" : "Mental filtering occurs when a person focuses solely on the negative aspects of an experience while filters out all the positives aspects of a situation, magnifying those negative details and disqualifying the positive.",
        "Over-Generalization" : "Over-generalization occurs when a person focuses on a single event that occurred and makes a conclusion based on this single piece of negative evidence. A person define themselves and others based on a single event or behavior.",
        "Polarized thinking" : "Polarized thinking is when you have an ‘All-or-Nothing’ or ‘Black and White’ thinking pattern. A person believes they have to be perfect or they are a complete failure because they see things in terms of ‘either/or’ categories. ",
        "Fallacies" : "Fallacy of Fairness assumes that all things in life should be measured based on equality, being disappointed since most things in reality aren’t fair. Control fallacies is the belief that a person’s life is totally controlled by external factors.",
        "Catastrophizing" : "Catastrophizing thoughts occur when the magnitude is exaggerated or diminished. It leads to worries escalating quickly and becoming the worst-case scenario, or it consists of minimizing positive experiences.",
        "Blaming" : "Blaming is when an individual tend to play a victim role and hold other people responsible for their pain. Self-blame consists of blaming themselves for circumstances that aren’t their fault, or are beyond their control.",
        "Jumping to conclusion" : "This distortion occurs when you think you know what the other person is thinking. You assume what other people’s intentions are and take that interpretation as the only valid reasoning. The prediction is arbitrary and has a negative outcome.",
        "Emotional reasoning" : "Whatever emotion a person is feeling during this thought distortion must be true in their mind. They are incorrectly assuming that the negative feeling brought out by their emotions is the only truth. It can be related to the need of always be right."
    ]
    init(key: String){
        self.key = key
    }
    var body: some View {
        
        ZStack {
            VStack (alignment: .leading, spacing: 55){
                
//                HStack {
                    Text(key)
                        .multilineTextAlignment(.leading)
                        .font(.custom(FontsManager.Syne.bold, size:20))
                    .foregroundColor(Color("CustomBlack"))

                
                HStack (alignment: .center){
                    
                    Spacer()
                    Image(key)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 75)
                    Spacer()
                    
                }
                
                Text(cognitiveErrors[key]!)
                    .font(.custom(FontsManager.Syne.medium, size:18))
                    .foregroundColor(Color("CustomGray"))
                
            }
            .padding(.bottom, 40)
            .padding()
            .onAppear{
                print("Cognitive error: \(key)")
            }
        }
    }
}

struct HalfModalView_Previews: PreviewProvider {
    static var previews: some View {
        HalfModalView(key: "Mental filtering")
    }
}
