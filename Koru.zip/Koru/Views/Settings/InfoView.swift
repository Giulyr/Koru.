//
//  InfoView.swift
//  Koru
//
//  Created by Giulls on 08/06/22.
//

import SwiftUI

struct InfoView: View {
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        
        ZStack(alignment: .top){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            VStack (alignment: .leading){
                
                VStack (alignment: .leading, spacing: 40){
                    
                    Text("""
The information contained on the Service is for general information purposes only.

Your use of any aspect of the Service is at your own risk. You must consult with healthcare providers and make your medical decisions based on their advice. Koru is not providing any medical advice of any kind. Information regarding medications, health, medical advice and otherwise may be provided by third parties, including other users of the service.
""")
                    .font(.custom(FontsManager.Syne.medium, size:18))
                    .foregroundColor(Color("CustomGray"))
                    .frame(height: 300, alignment: .leading)
                    
                }
                
                VStack (alignment: .leading, spacing: 10){
                    
                    Text("Contacts")
                        .font(.custom(FontsManager.Syne.bold, size:20))
                        .foregroundColor(Color("CustomBlack"))
                    //                    .frame(alignment: .leading)
                    
                    Text("""
If you have any questions, you can contact us:

kopikopikoteam@gmail.com
""")
                    .font(.custom(FontsManager.Syne.medium, size:18))
                    .foregroundColor(Color("CustomGray"))
                    .frame(height: 88, alignment: .leading)
                    
                }
                
            } //: VStack
            .padding(.horizontal, 15)
            .navigationBarTitle("Information", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }) //: NAVIGATION BAR ITEMS
        } //: ZStack
        .padding(.vertical, 16)
        .background(Color("CustomWhite"))
        
    } //: Struct
} //: View

struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
