//
//  InfoView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI

struct SettingsView: View {
    
    
    @AppStorage("time") var time : Date = Date()
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appState : AppState
    let notify = NotificationHandler()
    
    var body: some View {
        NavigationView{
        ZStack(alignment: .top){
            
            //MARK: - BACKGROUND
                            Color("CustomWhite")
                                .ignoresSafeArea(.all, edges: .all)
                            //: -Background
            
            VStack (spacing: 38){
                
                VStack {
                    HStack (spacing: 10){
    //                   MARK: - TIME PICKER
                        DatePicker("Notification time", selection: $time, displayedComponents: .hourAndMinute)
                            .padding()
                            .font(.custom(FontsManager.Syne.medium, size:18))
                            .frame(height: 90)
                        
                    } //: HStack
                    .frame(height: 62)
                    .background(
                        Capsule().strokeBorder(Color.white, lineWidth: 0)
                            .background(.white)
                            .cornerRadius(13)
                )
                    .padding(.horizontal, 16)
                    
                    Text("Your Koru is resetted everyday at midnight. Select the time you want to be notified to analyze your thoughts before they are reset.")
                        .font(.custom(FontsManager.Syne.regular, size:13))
                        .foregroundColor(Color("CustomGray"))
                        .frame(height: 48, alignment: .leading)
                        .padding(.horizontal, 32)
                    
                } //: VStack
                   
            
                
                // MARK: - BUTTON TO GO TO INFOVIEW
                
                Button (action: {
                    print("Next tapped")
                }, label: {
                    NavigationLink(destination: InfoView().navigationBarBackButtonHidden(true)) {
                        
                HStack {
                    
                    Text("Information")
                        .foregroundColor(Color("CustomBlack"))
                    
                    Spacer()
                    
                    Image(systemName: "chevron.right")
                        .foregroundColor(Color("CustomGray"))

           
                } //: HStack
                .padding()
                
                .font(.custom(FontsManager.Syne.medium, size:18))
                .frame(height: 62)
                .background(
                    Capsule().strokeBorder(Color.white, lineWidth: 0)
                        .background(.white)
                        .cornerRadius(13)
                )
                .padding(.horizontal, 16)
                    }
                }) //: Button
                
            } //: VStack
            .padding(.top, 25)
            

            .navigationBarTitle("Settings", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    let formatter = DateFormatter()
                    formatter.dateFormat = "hh:mm a"
                    let hour = formatter.string(from: time)

                    
                    notify.removeAllNotifications()
                    notify.sendNotifications(date: formatter.date(from: hour)! , type: "date", title: "Take a moment for yourself", body: "Remember that you have still nodes to unravel.")
                    withAnimation(){
                        appState.viewState = .mainView
                    }
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 27, height: 21.97)
                }
            }) //: NAVIGATION BAR ITEMS
        } //: - ZStack
        .padding(.vertical, 16)
        .background(Color("CustomWhite"))
        }
    } //: - Struct
} //: - View
extension Date: RawRepresentable {
    private static let formatter = ISO8601DateFormatter()
    
    public var rawValue: String {
        Date.formatter.string(from: self)
    }
    
    public init?(rawValue: String) {
        self = Date.formatter.date(from: rawValue) ?? Date()
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}

