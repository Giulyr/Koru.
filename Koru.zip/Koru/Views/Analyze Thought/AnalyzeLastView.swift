//
//  AnalyzeFourthView.swift
//  Koru
//
//  Created by Giulls on 07/06/22.
//

import SwiftUI
import SpriteKit

struct AnalyzeLastView: View {
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) private var viewContext
    @EnvironmentObject var appState : AppState
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Intrusive.id, ascending: true)])
    private var intrusive: FetchedResults<Intrusive>
    
    @EnvironmentObject var intrusiveArray : IntrusiveArray

    @Binding var positive : String
    @Binding var evidence : String
    @Binding var proof : String
    @Binding var selectedErrors : [String]
    @State var opacize : Bool = false
    @State var selectedString : String?
  
    var scene : AnalysisFinalWithAnimation {
        let scene = AnalysisFinalWithAnimation(size: CGSize(width: 372, height: 812))
        scene.scaleMode = .fill
        scene.appState = appState
        scene.intrusive = intrusiveArray
        return scene
    }
    var body: some View {
        ZStack (alignment: .top){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            
            SpriteView(scene: scene).ignoresSafeArea()
                
                VStack (){
//                    MARK: - SPACE FOR LINE
                    Image("analyze-basic")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 130)
                        .padding(.top, 50)
                        .opacity(0.0)
                    
//                    MARK: - SCROLL VIEW
                    
                        ScrollView (.vertical, showsIndicators: false){
                            
    //                        MARK: - TEXT
                            VStack (alignment: .leading, spacing: 40){
                                
                            VStack (alignment: .leading, spacing: 10){
                                    
                                    Text("Cognitive errors recognized")
                                        .font(.custom(FontsManager.Syne.bold, size:20))
                                
                                Text("\(selectedString ?? "")")
                                    .font(.custom(FontsManager.Syne.medium, size:18))
                                    .foregroundColor(Color("CustomGray"))
                                
                                
                            } //: VStack
                                
                                VStack (alignment: .leading, spacing: 10){
                                    
                                    Text("Your thought proofs")
                                        .font(.custom(FontsManager.Syne.bold, size:20))
                                
                                Text("\(proof)")
                                    .font(.custom(FontsManager.Syne.medium, size:18))
                                    .foregroundColor(Color("CustomGray"))
                                } //: VStack
                                
                                VStack (alignment: .leading, spacing: 10){
                                    Text("Its evidence contrary ")
                                        .font(.custom(FontsManager.Syne.bold, size:20))
                                
                                Text("\(evidence)")
                                    .font(.custom(FontsManager.Syne.medium, size:18))
                                    .foregroundColor(Color("CustomGray"))
                                } //: VStack
                                
                                VStack (alignment: .leading, spacing: 10){
                                    Text("The positive way")
                                        .font(.custom(FontsManager.Syne.bold, size:20))
                                
                                Text("\(positive)")
                                    .font(.custom(FontsManager.Syne.medium, size:18))
                                    .foregroundColor(Color("CustomGray"))
                                } //: VStack
                                
                                .frame(minHeight: 100, alignment: .top)

                                
                                VStack{
                                    EmptyView()
                                }
                                .frame(minWidth: UIScreen.main.bounds.width - 35)
                
                            } //: VStack
                            .padding(.horizontal, 15)
                            .padding(.top, 20)

                            //MARK: - BUTTON COLLECT
                        Button{
                            intrusive.nsPredicate = NSPredicate(format: "id == %@", intrusiveArray.selectedTought.id! as CVarArg)
                            print("\(String(describing: intrusive.first?.thought))")
                            for object in intrusive{
                                print("Cancella \(String(describing: object.thought))")
                                viewContext.delete(object)
                                PersistenceManager.shared.saveContext()
                                intrusiveArray.array = []
                                intrusiveArray.selectedTought = IntrusiveModel()
                            }
                            withAnimation(.easeInOut){
                                opacize = true
                                appState.isAnimating = true

                        }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                                withAnimation {
                                    appState.viewState = .mainView

                                }
                        }
                        } label: {
                            ButtonView (text: "Drop now")
                        } //: Button

                    } //: SCROLL VIEW
                }.opacity(opacize ? 0 : 1) //: VStack

            .navigationBarTitle("Analyze", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }.opacity(opacize ? 0 : 1)
            }) //: NAVIGATION BAR ITEMS
        }.onAppear{
            selectedString = selectedErrors.joined(separator: ", ")
        } //: ZStack
        
    } //: View
} //: Struct

struct AnalyzeLastView_Previews: PreviewProvider {
   
    
    static var previews: some View {
        AnalyzeLastView(positive: .constant("POSITIVE EXAMPLE"), evidence: .constant("EVIDENCE EXAMPLE"), proof: .constant("PROOF EXAMPLE"), selectedErrors: .constant([""])).environmentObject(AppState()).environmentObject(IntrusiveArray())
    }
}
