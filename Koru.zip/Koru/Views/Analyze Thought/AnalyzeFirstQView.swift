//
//  AnalysisView.swift
//  Koru
//
//  Created by Giulls on 07/06/22.
//

import SwiftUI

struct AnalyzeFirstQView: View {
    
    @EnvironmentObject var appState : AppState
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @Environment(\.presentationMode) var presentationMode
    @State var proof : String = ""
    @State var positive : String = ""
    @State var evidence : String = ""
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)
    @Binding var feelknots : [String : String]
    @Binding var selectedErrors : [String] 
    var body: some View {
        ZStack (alignment: .top){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            
            VStack (alignment: .leading) {
                if let feel = intrusiveArray.selectedTought.feel {
                Image(feelknots[feel]!)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 15)
                }
                VStack (alignment: .leading, spacing: 20){
                    
                    Text("What are the proofs that can confirm your thought?")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                        .frame(height: 70)
                    
//               MARK: TEXTEDITOR 
                    VStack(alignment: .trailing){
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color.white)
                        
                        if proof.isEmpty {
                            Text("Describe what evidence confirms your thinking")
                                .font(.custom("Syne", size: 16))
                                .foregroundColor(Color(UIColor.placeholderText))
                                .padding(.top, 12)
                                .padding(.leading, 8)


                        }
                        
                        TextEditor(text: $proof)
                            .font(.custom("Syne", size: 16))
                            .limitInputLength(value: $proof, length: 220)
                            .disableAutocorrection(true)
                            .padding(.leading, 4)
                    }
                    .frame(width:textFieldwidth, height: 109)
                    .cornerRadius(15)

                        CounterView(text: $proof)
                    }
                } //: VStack
                .padding(.horizontal)
                .padding(.top, 40)
            } //: VStack
            
            
            .navigationBarTitle("Analyze", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                
                NavigationLink(destination: AnalyzeSecondQView(positive: $positive, evidence: $evidence, proof: $proof, selectedErrors: $selectedErrors, feelknots: $feelknots)            .environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !proof.isEmpty ? Color("CustomBlack") : .secondary
              )
                    
                }.disabled(proof.isEmpty)
                   
            }) //: NAVIGATION BAR ITEMS
        } .onTapGesture {
            self.hideKeyboard()
        } //: ZStack
        
    } //: View
} //: Struct


struct AnalyzeFirstQView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyzeFirstQView(feelknots: .constant(["Angry": ""]), selectedErrors:.constant([""])).environmentObject(IntrusiveArray()).environmentObject(AppState())
    }
}
