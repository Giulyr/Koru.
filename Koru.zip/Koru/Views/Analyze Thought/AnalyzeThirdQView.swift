//
//  AnalyzeThirdView.swift
//  Koru
//
//  Created by Giulls on 07/06/22.
//

import SwiftUI

struct AnalyzeThirdQView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @EnvironmentObject var appState : AppState
    @Binding var positive : String
    @Binding var evidence : String
    @Binding var proof : String
    @Binding var selectedErrors : [String]
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)
    @Binding var feelknots : [String : String]
    
    var body: some View {
        ZStack (alignment: .top){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            
            VStack (alignment: .leading){
                
                if let feel = intrusiveArray.selectedTought.feel {
                    
                Image(feelknots[feel]!)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 15)
                }
                VStack (alignment: .leading, spacing: 20){
                    
                    Text("Can you try to re-elaborate this thought in a positive way?")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                        .frame(height: 70)
                    
                    //               MARK: TEXTEDITOR
                    
                    VStack(alignment: .trailing){
                        ZStack(alignment: .topLeading) {
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .fill(Color.white)
                            
                            if positive.isEmpty {
                                Text("Elaborate your thought alternatively in a functional one")
                                    .font(.custom("Syne", size: 16))
                                    .foregroundColor(Color(UIColor.placeholderText))
                                    .padding(.top, 12)
                                    .padding(.leading, 8)

                            }
                            
                            TextEditor(text: $positive)
                                .font(.custom("Syne", size: 16))
                                .limitInputLength(value: $positive, length: 220)
                                .disableAutocorrection(true)
                                .padding(.leading, 4)
                        }
                        
                        .frame(width:textFieldwidth, height: 109)
                        .cornerRadius(15)
                        //    :TextEditor
                        CounterView(text: $positive)
                    }
                } //: VStack
                .padding(.horizontal)
                .padding(.top, 40)

            } //: VStack
            
            
            .navigationBarTitle("Analyze", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                
                NavigationLink(destination: AnalyzeLastView(positive: $positive, evidence: $evidence, proof: $proof, selectedErrors: $selectedErrors)            .environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !positive.isEmpty ? Color("CustomBlack") : .secondary
                        )
                }
                .disabled(positive.isEmpty)
            }) //: NAVIGATION BAR ITEMS
        } .onTapGesture {
            self.hideKeyboard()
        }//: ZStack
        
    } //: View
} //: Struct

struct AnalyzeThirdQView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyzeThirdQView(positive: .constant(""), evidence: .constant(""), proof: .constant(""), selectedErrors: .constant([""]), feelknots: .constant(["Angry": ""])).environmentObject(IntrusiveArray()).environmentObject(AppState())
    }
}
