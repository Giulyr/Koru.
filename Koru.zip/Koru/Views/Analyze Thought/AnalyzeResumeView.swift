//
//  AnalyzeResumeView.swift
//  Koru
//
//  Created by Giulls on 08/06/22.
//

import SwiftUI

struct AnalyzeResumeView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appState : AppState
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    //    var intrusive : Intrusive
    @State var feelknots : [String : String] = ["Afraid": "4-thought-afraid","Angry" : "4-thought-angry", "Anxious" : "4-thought-anxious", "Disgusted" : "4-thought-disgusted", "Guilty" : "4-thought-guilty", "Sad" : "4-thought-sad"
    ]
    @State var feelNode : String = ""
    
    var body: some View {
        
        NavigationView {
            
            ZStack(alignment: .top) {
                
                //MARK: - BACKGROUND
                Color("CustomWhite")
                    .ignoresSafeArea(.all, edges: .all)
                //: -Background
                
                VStack(alignment: .leading) {
                    //                        MARK: - SPACE FOR LINE
                    if let feel = intrusiveArray.selectedTought.feel {
                        
                    Image(feelknots[feel]!)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 130)
                        .padding(.top, 50)
                    }
                    
                    //                            MARK: - TEXT
                    ScrollView(showsIndicators: false) {
                        VStack (alignment: .leading, spacing: 30){
                            
                            Text("Today, you were feeling \(intrusiveArray.selectedTought.feel.lowercased()).")
                                .font(.custom(FontsManager.DMSerif.regular, size:25))
                            
                            VStack (alignment: .leading, spacing: 10){
                                Text("Where you were")
                                    .font(.custom(FontsManager.Syne.bold, size:20))
                                if let thought = intrusiveArray.selectedTought.context{
                                    Text(thought)
                                        .font(.custom(FontsManager.Syne.medium, size:18))
                                        .foregroundColor(Color("CustomGray"))
                                }
                                
                            }
                            VStack (alignment: .leading, spacing: 10){
                                Text("Your thought")
                                    .font(.custom(FontsManager.Syne.bold, size:20))
                                
                                if let thought = intrusiveArray.selectedTought.thought{
                                    Text(thought)
                                        .font(.custom(FontsManager.Syne.medium, size:18))
                                        .foregroundColor(Color("CustomGray"))
                                }
                                
                                Spacer()
                            }
                        }.padding()
                    } //: VStack
                    .padding(.top, 25)
                } //: VStack
                
                
                .navigationBarTitle("Analyze", displayMode: .inline)
                
                //MARK: - NAVIGATION BAR ITEMS
                .navigationBarItems(leading:
                                        HStack {
                    
                    Button{
                        withAnimation(){
                            print("Back tapped")
                            appState.viewState = .mainView
                        }
                        
                    } label : {
                        
                        Image("BackButton")
                            .resizable()
                            .scaledToFit()
                    }
                }, trailing:
                                        HStack {
                    
                    NavigationLink(destination: AnalyzeFirst(feelknots: $feelknots).navigationBarBackButtonHidden(true)    .environmentObject(appState)){
                        Text("Next")
                            .font(.custom(FontsManager.Syne.regular, size:17))
                            .foregroundColor(Color("CustomBlack"))
                    }
                    
                }) //: NAVIGATION BAR ITEMS
                
            }
        } //: ZStack
        
    } //: View
} //: Struct


struct AnalyzeResumeView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyzeResumeView().environmentObject(IntrusiveArray()).environmentObject(AppState())
    }
}

