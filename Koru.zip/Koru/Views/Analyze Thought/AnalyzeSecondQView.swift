//
//  AnalyzeSecondView.swift
//  Koru
//
//  Created by Giulls on 07/06/22.
//

import SwiftUI

struct AnalyzeSecondQView: View {
    @EnvironmentObject var appState : AppState
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @Binding var positive : String
    @Binding var evidence : String
    @Binding var proof : String
    @Binding var selectedErrors : [String]
    let textFieldwidth : CGFloat = (UIScreen.main.bounds.size.width * 0.923)
    @Binding var feelknots : [String : String]
    var body: some View {
        ZStack (alignment: .top){
            
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            
            VStack (alignment: .leading){
                
                if let feel = intrusiveArray.selectedTought.feel {
                    
                Image(feelknots[feel]!)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 15)
                    }
                VStack (alignment: .leading, spacing: 13){
                    
                    Text("Is there any evidence contrary to this thought?")
                        .font(.custom(FontsManager.DMSerif.regular, size:25))
                        .frame(height: 90)
                    //               MARK: TEXTEDITOR CON PLACEHOLDER
                    VStack(alignment: .trailing){
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 8, style: .continuous)
                            .fill(Color.white)
                        
                        if evidence.isEmpty {
                            Text("""
Descrive any objective evidence or any facts that
you are neglecting or ignoring.
""")
                                .font(.custom("Syne", size: 16))
                                .foregroundColor(Color(UIColor.placeholderText))
                                .padding(.top, 12)
                                .padding(.leading, 8)
//                         
                        }
                        
                        TextEditor(text: $evidence)
                            .font(.custom("Syne", size: 16))
                            .limitInputLength(value: $evidence, length: 220)
                            .disableAutocorrection(true)
                            .padding(.leading, 5)
                        
                    }
                    .frame(width: textFieldwidth, height: 109)
                    .cornerRadius(15)

                    //    :TextEditor
                    CounterView(text: $evidence)
                    }
                } //: VStack
                .padding(.horizontal)
                .padding(.top, 30)

            } //: VStack
            
            
            .navigationBarTitle("Analyze", displayMode: .inline)
            
            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                
                NavigationLink(destination: AnalyzeThirdQView(positive: $positive, evidence: $evidence, proof: $proof, selectedErrors: $selectedErrors, feelknots: $feelknots)            .environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !evidence.isEmpty ? Color("CustomBlack") : .secondary
              )
                }
                .disabled(evidence.isEmpty)
            }) //: NAVIGATION BAR ITEMS
        } .onTapGesture {
            self.hideKeyboard()
        } //: ZStack
        
    } //: View
} //: Struct

struct AnalyzeSecondQView_Previews: PreviewProvider {
    static var previews: some View {
        AnalyzeSecondQView (positive: .constant(""), evidence: .constant(""), proof: .constant("ciao"), selectedErrors: .constant([""]), feelknots: .constant(["Angry": ""])).environmentObject(IntrusiveArray()).environmentObject(AppState())
    }
}
