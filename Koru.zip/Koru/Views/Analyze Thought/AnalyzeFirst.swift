//
//  AnalyzeFirst.swift
//  Koru
//
//  Created by Giulls on 08/06/22.
//

import SwiftUI

struct AnalyzeFirst: View {
    
    @EnvironmentObject var appState : AppState
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @Environment(\.presentationMode) var presentationMode
    @State var selectedErrors : [String] = []
    @State var Num : Int = 0

    @Binding var feelknots : [String : String]
    var body: some View {
        
        ZStack{
            //MARK: - BACKGROUND
            Color("CustomWhite")
                .ignoresSafeArea(.all, edges: .all)
            //: -Background
            VStack (alignment: .leading){
              
                
                if let feel = intrusiveArray.selectedTought.feel {
                Image(feelknots[feel]!)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 130)
                    .padding(.top, 50)
                }
                VStack(alignment: .trailing){
                    
                    VStack (alignment: .leading) {
                        Text ("Is there any cognitive error?")
                            .font(.custom(FontsManager.DMSerif.regular, size:25))
                            .padding()
    
                        CognitiveCardView(selectedErrors: $selectedErrors, Num: $Num)
                        
                    } //: VStack

                    
                    Group{
                        Text("Selected ") .foregroundColor(Color("CustomGray-Medium")) +
                        Text ("\(Num) ") .foregroundColor(Color("CustomBlack")) +
                        Text ("/ 3") .foregroundColor(Color("CustomGray-Medium"))
                    }
                  .padding(.trailing, 27)
                  .padding(.top, 10)
                        .font(.custom(FontsManager.Syne.regular, size: 16))
                        
                }
                .padding(.bottom, 84)
              
            } //: VStack
            
            .navigationBarTitle("Analyze", displayMode: .inline)

            //MARK: - NAVIGATION BAR ITEMS
            .navigationBarItems(leading:
                                    HStack {
                Button{
                    print("Back tapped")
                    
                    presentationMode.wrappedValue.dismiss()
                    
                } label : {
                    
                    Image("BackButton")
                        .resizable()
                        .scaledToFit()
                }
            }, trailing:
                                    HStack {
                
                NavigationLink(destination: AnalyzeFirstQView(feelknots: $feelknots, selectedErrors: $selectedErrors)                            .environmentObject(appState).navigationBarBackButtonHidden(true)){
                    Text("Next")
                        .font(.custom(FontsManager.Syne.regular, size:17))
                        .foregroundColor(
                            !selectedErrors.isEmpty ? Color("CustomBlack") : .secondary
                        )
                }
                .disabled(selectedErrors.isEmpty)
            }) //: NAVIGATION BAR ITEMS
        }
    }
}


struct AnalyzeFirst_Previews: PreviewProvider {
    static var previews: some View {
        AnalyzeFirst(selectedErrors: [], feelknots: .constant(["Angry": ""])).environmentObject(IntrusiveArray()).environmentObject(AppState())
    }
}
