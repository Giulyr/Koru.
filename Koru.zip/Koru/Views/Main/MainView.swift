//
//  MainView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI
import SpriteKit
import CoreData
import SwiftUITooltip

struct MainView: View {
    @EnvironmentObject var appState : AppState
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @AppStorage("showHint") var showHint : Bool = true
    private var date: Date?
    @State var shown : Bool = false
    @State var tooltip : DefaultTooltipConfig = DefaultTooltipConfig()
    init(){
        self.tooltip.side = .top
        self.tooltip.animationTime = 1
        self.tooltip.animationOffset = 10
        self.tooltip.backgroundColor = .white
        self.tooltip.borderColor = .clear
        self.tooltip.showArrow = showHint
        self.tooltip.arrowHeight = 15
        self.tooltip.arrowWidth = 10
    }
    var scene : RopeView {
        let scene = RopeView(size: CGSize(width: 372, height: 812))
        scene.scaleMode = .fill
        scene.appState = appState
        scene.intrusive = intrusiveArray.array
        scene.selectedIntrusive = intrusiveArray
        return scene
    }
    var body: some View {
        ZStack{
            NavigationView {
                SpriteView(scene: scene).ignoresSafeArea().environmentObject(appState).environmentObject(intrusiveArray)
                //            MARK: - NAVIGATION BAR ITEMS
                    .navigationBarItems(leading:
                                            HStack {
                        Image("SettingButton")
                            .resizable()
                            .scaledToFit().onTapGesture {
                                withAnimation(){
                                    appState.viewState = .settings
                                }
                            }
                            .frame(height: 25)
                        
                    }, trailing:
                                            HStack {
                        Button{
                            print("Add tapped")
                            withAnimation(){
                                showHint = false
                                if intrusiveArray.array.count < 6 {
                                    appState.viewState = .addView
                                } else {
                                    self.shown.toggle()
                                }
                            }
                            
                        } label : {
                            
                            Image("AddButton")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 25)
//                                .tooltip(.leadingBottom,config: tooltip){
//                                    if (showHint){
//                                        Text("Tap here to add your thoughts")
//                                            .padding()
//                                            .font(.custom(FontsManager.Syne.regular, size:18))
//                                            .foregroundColor(Color("CustomGray"))
//                                            .border(.clear, width: 0)
//                                            .frame(height: 45)
//                                    }
//                                }
                            
                        }
                    })
            }
            if shown {
                AlertFullView(shown: $shown)
            }
        }
    } //: View
} //: Struct


struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView().environmentObject(AppState()).environmentObject(IntrusiveArray())
    }
}
