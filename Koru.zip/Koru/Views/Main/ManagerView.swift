//
//  ManagerView.swift
//  Koru
//
//  Created by Giulls on 01/06/22.
//

import SwiftUI
import SpriteKit
import AVFoundation

extension UserDefaults {
    
    var isOnboardingCompleted : Bool {
        get {
            return (UserDefaults.standard.value(forKey: "isOnboardingCompleted")
                    as? Bool) ?? false
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "isOnboardingCompleted")
        }
    }
}

struct ManagerView: View {
    let notify = NotificationHandler()
    @EnvironmentObject var intrusiveArray : IntrusiveArray
    @EnvironmentObject var appState : AppState
    @AppStorage("time") var time : Date = Date()
    private var date: Date?
    @FetchRequest(sortDescriptors: [NSSortDescriptor(keyPath: \Intrusive.date, ascending: true)])
    private var intrusive: FetchedResults<Intrusive>
    init(){
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        let day = formatter.string(from: Date.now)
        let string = "\(day) 12:01 AM"
        print("DATE: \(string)")
        formatter.dateFormat = "dd/MM/yyyy hh:mm a"
        self.date = formatter.date(from: string)
    }
    var body: some View {
        
        if  UserDefaults.standard.isOnboardingCompleted {
            switch appState.viewState {
            case .mainView :
                MainView().environmentObject(appState).environmentObject(intrusiveArray).onAppear{
                    print("UPDATE MAINVIEW")
                    appState.viewState = .mainView
                    intrusive.nsPredicate = NSPredicate(format: "date > %@", date! as CVarArg)
                    var array:[IntrusiveModel] = []
                    for intr in intrusive {
                        print("SENSAZIONE:")
                        print(intr.feel!)
                        let intrusiveMod = IntrusiveModel(id: intr.id!, context: intr.context!, date: intr.date!, feel: intr.feel!, thought: intr.thought!)
                        array.append(intrusiveMod)
                        intrusiveArray.array = array
                    }
                }
            case .analyzeView :
                AnalyzeResumeView().environmentObject(appState).environmentObject(intrusiveArray).transition(.asymmetric(insertion: .opacity, removal: .opacity))
            case .addView:
                AddThoughtView().environmentObject(appState).transition(.asymmetric(insertion: .move(edge: .trailing), removal: .opacity))
            case .settings:
                SettingsView().environmentObject(appState).transition(.asymmetric(insertion: .move(edge: .trailing), removal: .slide))
            }
        } else {
            OnboardingView().environmentObject(appState).onAppear{
                notify.askPermission()
            }
        }
        
    }
}

struct ManagerView_Previews: PreviewProvider {
    static var previews: some View {
        ManagerView().environmentObject(AppState()).environmentObject(IntrusiveArray())
    }
}

extension View {
    func setNavbarTitleColor(color : Color){
        
    }
    func setNavbarTitleFont(font : Font){
        
    }
    
}

extension UINavigationController{
    
    open override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationBar.titleTextAttributes = [.foregroundColor : UIColor(named : "CustomBlack"), .font : UIFont(name: "Syne-Bold", size: 17)]
      
    }
}
