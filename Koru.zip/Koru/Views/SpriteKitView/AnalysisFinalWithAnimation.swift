//
//  FinalAnimation.swift
//  Koru
//
//  Created by Jarvis on 14/06/22.
//

import Foundation
import SpriteKit

class AnalysisFinalWithAnimation : SKScene, SKPhysicsContactDelegate {
    
    var intrusive : IntrusiveArray?
    var appState : AppState?
    var line : SKShapeNode?
    var spheres : [Sphere] = []
    var sphere : Sphere?
    var sphereFall : Sphere?
    var points : [CGPoint] = [CGPoint(x: -16, y: -164), CGPoint(x: 106, y: -198),CGPoint(x: 218, y: -163),CGPoint(x: 296, y: -171),CGPoint(x: 373, y: -147)]
    var action : SKAction?
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        self.anchorPoint = CGPoint(x: 0, y: 1)
        self.backgroundColor = UIColor(named: "CustomWhite")!
        
        switch (intrusive?.selectedTought.feel){
        case "Sad" :
            self.sphere = Sphere(emotion: .sad, intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .sad, intrusive: IntrusiveModel())
        case "Afraid":
            self.sphere = Sphere(emotion: .afraid,intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .afraid,intrusive: IntrusiveModel())
        case "Angry":
            self.sphere = Sphere(emotion: .angry,intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .angry,intrusive: IntrusiveModel())
        case "Disgusted":
            self.sphere = Sphere(emotion: .disgusted, intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .disgusted, intrusive: IntrusiveModel())
        case "Anxious":
            self.sphere = Sphere(emotion: .anxious,intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .anxious,intrusive: IntrusiveModel())
        case "Guilty":
            self.sphere = Sphere(emotion: .guilty,intrusive: IntrusiveModel())
            self.sphereFall = Sphere(emotion: .guilty,intrusive: IntrusiveModel())
        default:
            return
        }
       
        for i in 0..<points.count{
            if i == 2{
                self.sphere?.position = points[i]
                self.spheres.append(sphere!)
                self.addChild(sphere!)
                let newAnchor = Sphere()
                newAnchor.position = self.sphere!.position
                newAnchor.position.y += 2
                self.addChild(newAnchor)
                let joint = SKPhysicsJointSpring.joint(withBodyA: sphere!.physicsBody!, bodyB: newAnchor.physicsBody!, anchorA: sphere!.position, anchorB: newAnchor.position)
                joint.frequency = 2
                joint.damping = 0.5
                self.physicsWorld.add(joint)
            }else{
                let sphere = Sphere()
                sphere.position = points[i]
                self.spheres.append(sphere)
                self.addChild(sphere)
            }
        }
        self.line = SKShapeNode(splinePoints: &points, count: points.count)
        
        self.line!.strokeColor = UIColor.black
        self.line!.lineWidth = 2
        self.line!.zPosition = -1
        self.addChild(self.line!)
        self.sphere?.physicsBody?.isDynamic = false
        self.sphereFall?.position = sphere!.position
        self.sphereFall?.position.y = (sphere?.position.y)! - 100
        self.sphereFall?.alpha = 0
        addChild(self.sphereFall!)
        
        
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        writeLine()
        if (appState?.isAnimating == true){
            self.appState?.isAnimating = false
            let wait = SKAction.wait(forDuration: 2)
            let move = SKAction.move(by: CGVector(dx: 0, dy: -100), duration: 1)
            let disappear = SKAction.run {
                self.sphere?.isActive = false
                self.sphere?.disappear()
                self.sphere?.physicsBody?.isDynamic = true
                self.sphereFall?.alpha = 1
                self.sphereFall?.physicsBody?.isDynamic = true
                self.sphereFall?.physicsBody?.affectedByGravity = true
            }
        
            print("IS ANIMATING")
            self.sphere?.run(SKAction.sequence([wait,move,disappear]))
        }
    }
    
    func writeLine(){
        self.line!.removeFromParent()
        self.points.removeAll()
        for sphere in self.spheres {
            self.points.append(sphere.position)
        }
        self.line = SKShapeNode(splinePoints: &points, count: points.count)
        self.line!.strokeColor = UIColor.black
        self.line!.lineWidth = 2
        self.line!.zPosition = -1
        self.addChild(self.line!)
    }
}

