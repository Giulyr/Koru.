//
//  RopeView.swift
//  Koru
//
//  Created by Jarvis on 31/05/22.
//

import Foundation
import SpriteKit
import GameplayKit
import UIKit
import SwiftUI

public struct PhysicsCategory {
    static let none      : UInt32 = 0
    static let all       : UInt32 = UInt32.max
    static let sphere    : UInt32 = 0b1
    static let circle  : UInt32 = 0b10
}
class RopeView: SKScene, SKPhysicsContactDelegate, UIGestureRecognizerDelegate {
    
    var hapticEngine = CustomHaptics()
    var appState : AppState?
    var rope : Rope?
    var spheres : [Sphere] = []
    var circle = SKSpriteNode(imageNamed: "CircleTraited")
    var isButtonActive = false
    var isTouchingButton = false
    var currentButton : Sphere?
    var dragLabel = SKLabelNode()
    var swipeUpLabel = SKLabelNode()
    var longPressLabel = SKLabelNode()
    var date : Date?
    var intrusive : [IntrusiveModel]?
    var selectedIntrusive : IntrusiveArray?
    
    override init(size: CGSize){
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        self.anchorPoint = CGPoint(x: 0, y: 1)
        self.backgroundColor = UIColor(named: "CustomWhite")!
        let pressed:UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(longPress(sender:)))
        pressed.delegate = self
        pressed.minimumPressDuration = 1
        view.addGestureRecognizer(pressed)
        
        let swipeGestureRecognizerUp = UISwipeGestureRecognizer(target: self, action: #selector(didSwipe(_:)))
        swipeGestureRecognizerUp.direction = .up
        view.addGestureRecognizer(swipeGestureRecognizerUp)
        

        
        self.dragLabel.text = "Drag the thought here"
        self.dragLabel.fontName = "Syne"
        self.dragLabel.fontSize = 16
        self.dragLabel.fontColor = UIColor(named: "CustomGray")

        self.swipeUpLabel.text = " SWIPE UP to lay your current\nthought and drag another one"
        self.swipeUpLabel.numberOfLines = 2
        self.swipeUpLabel.verticalAlignmentMode = .center
        self.swipeUpLabel.fontName = "Syne"
        self.swipeUpLabel.fontSize = 16
        self.swipeUpLabel.fontColor = UIColor(named: "CustomGray")
        
        self.longPressLabel.text = "Long press to analyze"
        self.longPressLabel.fontName = "Syne"
        self.longPressLabel.fontSize = 16
        self.longPressLabel.fontColor = UIColor(named: "CustomGray")
        
        circle.position = CGPoint(x: 186, y: -597)
        circle.zPosition = -2
        circle.name = "circle"
        let circlePhysics = SKPhysicsBody(circleOfRadius: 40)
        circle.physicsBody = circlePhysics
        circle.physicsBody?.affectedByGravity = false
        circle.physicsBody?.isDynamic = true
        circle.physicsBody?.categoryBitMask = PhysicsCategory.circle
        circle.physicsBody?.contactTestBitMask = PhysicsCategory.sphere
        circle.physicsBody?.collisionBitMask = 0
        self.dragLabel.position = circle.position
        self.dragLabel.position.y -= 100
        self.swipeUpLabel.position = circle.position
        self.swipeUpLabel.position.y -= 100
        self.swipeUpLabel.alpha = 0
        self.longPressLabel.position = circle.position
        self.longPressLabel.position.y -= 100
        self.longPressLabel.alpha = 0
        
        if !intrusive!.isEmpty{
            for i in 0..<intrusive!.count {
                switch (intrusive![i].feel){
                case "Sad" :
                    self.spheres.append(Sphere(emotion: .sad, intrusive: intrusive![i]))
                case "Afraid":
                    self.spheres.append(Sphere(emotion: .afraid,intrusive: intrusive![i]))
                case "Angry":
                    self.spheres.append(Sphere(emotion: .angry,intrusive: intrusive![i]))
                case "Disgusted":
                    self.spheres.append(Sphere(emotion: .disgusted, intrusive: intrusive![i]))
                case "Anxious":
                    self.spheres.append(Sphere(emotion: .anxious,intrusive: intrusive![i]))
                case "Guilty":
                    self.spheres.append(Sphere(emotion: .guilty,intrusive: intrusive![i]))
                default:
                    return
                }
            }
        }

        self.rope = Rope(spheres: self.spheres, parent: self)
        addChild(rope!)
        addChild(circle)
        addChild(dragLabel)
        addChild(swipeUpLabel)
        addChild(longPressLabel)
        self.spheres = self.rope!.spheres
        createChain()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            for sphere in spheres {
                sphere.physicsBody?.isDynamic = false
                if sphere.contains(location) && sphere.isActive && !self.isButtonActive{
                    sphere.isCurrent = true
                }
                if sphere.contains(location) && self.isButtonActive && (self.currentButton != sphere){
                    self.longPressLabel.run(SKAction.fadeOut(withDuration: 0.2))
                    self.dragLabel.run(SKAction.fadeOut(withDuration: 0.2))
                    self.swipeUpLabel.run(SKAction.fadeIn(withDuration: 0.2))
                }
            }
            if isButtonActive && circle.contains(location){
                isTouchingButton = true
            }
        }
    }
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            for sphere in spheres {
                if sphere.isCurrent && self.currentButton != sphere {
                    sphere.position = location
                }
            }
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for _ in touches {
            for sphere in spheres {
                if sphere.isCurrent {
                    if !isButtonActive && (currentButton != sphere){
                        sphere.physicsBody?.isDynamic = true
                    }
                    sphere.isCurrent = false
                }
            }
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody: SKPhysicsBody = contact.bodyA
        let secondBody: SKPhysicsBody = contact.bodyB
//MARK: SAD CONTACT
        if let node = firstBody.node, node.name == "sad", let node2 = secondBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
        if let node = secondBody.node, node.name == "sad",let node2 = firstBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)

        }
//MARK: AFRAID CONTACT
        if let node = firstBody.node, node.name == "afraid",let node2 = secondBody.node, node2.name == "circle"{
        animateSelectedThought(activeNode: node, contact: contact)

        }
        if let node = secondBody.node, node.name == "afraid",let node2 = firstBody.node, node2.name == "circle"{
        print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
        
//MARK: ANXIOUS CONTACT
        if let node = firstBody.node, node.name == "anxious",let node2 = secondBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)

        }
        if let node = secondBody.node, node.name == "anxious",let node2 = firstBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }

//MARK: DISGUSTED CONTACT
        if let node = firstBody.node, node.name == "disgusted",let node2 = secondBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
        if let node = secondBody.node, node.name == "disgusted",let node2 = firstBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
//MARK: GUILTY CONTACT
        if let node = firstBody.node, node.name == "guilty",let node2 = secondBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
        if let node = secondBody.node, node.name == "guilty",let node2 = firstBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
//MARK: ANGRY CONTACT
        if let node = firstBody.node, node.name == "angry",let node2 = secondBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
        if let node = secondBody.node, node.name == "angry",let node2 = firstBody.node, node2.name == "circle"{
            print("CONTATTO")
        animateSelectedThought(activeNode: node, contact: contact)
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        self.rope?.writeLine()
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            return true
    }
    func createChain() {
        for sphere in spheres {
            if sphere.isActive == true{
                let newAnchor = Sphere()
                newAnchor.position = sphere.position
                newAnchor.position.y += 2
                self.addChild(newAnchor)
                let joint = SKPhysicsJointSpring.joint(withBodyA: sphere.physicsBody!, bodyB: newAnchor.physicsBody!, anchorA: sphere.position, anchorB: newAnchor.position)
                    joint.frequency = 2
                joint.damping = 0.5
                self.physicsWorld.add(joint)
            }
            
        }
    }
    
    func animateSelectedThought(activeNode: SKNode, contact: SKPhysicsContact){
        let sphere = activeNode as! Sphere
        sphere.physicsBody?.isDynamic = false
        self.currentButton = sphere
        
        for i in 0..<spheres.count{
            if sphere == spheres[i]{
                selectedIntrusive!.selectedTought = spheres[i].intrusive!
                print("selected intrusive \(selectedIntrusive!.selectedTought.thought )")
            }
        }
        
        let move = SKAction.move(to: self.circle.position, duration: 0.2)
        let resize = SKAction.resize(toWidth: 50, height: 50, duration: 0.2)
        let activate = SKAction.run {
            self.isButtonActive = true
        }
        sphere.run(move)
        sphere.symbol.run(SKAction.sequence([resize,activate]))
        self.dragLabel.run(SKAction.fadeOut(withDuration: 0.2))
        self.swipeUpLabel.run(SKAction.fadeOut(withDuration: 0.2))
        self.longPressLabel.run(SKAction.fadeIn(withDuration: 0.2))
        
    }
    
    @objc private func didSwipe(_ sender: UISwipeGestureRecognizer) {
        if isButtonActive{
            let move = SKAction.moveTo(y: self.circle.position.y + 50, duration: 0.1)
            let resize = SKAction.resize(toWidth: 25, height: 25, duration: 0.2)
            let activate = SKAction.run {
                self.isButtonActive = false
                self.currentButton?.physicsBody?.isDynamic = true
                self.currentButton = nil
            }
            self.currentButton?.run(move)
            self.currentButton!.symbol.run(SKAction.sequence([resize,activate]))
            
            self.swipeUpLabel.run(SKAction.fadeOut(withDuration: 0.2))
            self.longPressLabel.run(SKAction.fadeOut(withDuration: 0.2))
            self.dragLabel.run(SKAction.fadeIn(withDuration: 0.2))
        }
    }
    
    @objc func longPress(sender: UILongPressGestureRecognizer) {

         if sender.state == .began { print("LongPress BEGAN detected")
             if isTouchingButton {
                 print("\(selectedIntrusive!.selectedTought.thought )")
                 hapticEngine.playHaptic(intensity: 0.6, sharpness: 0.3, duration: 0.4)
                 withAnimation(){
                     appState?.viewState = .analyzeView
                 }
             }
         }
         if sender.state == .ended { print("LongPress ENDED detected")
            
         }

    }
}
