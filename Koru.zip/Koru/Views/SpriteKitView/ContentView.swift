//
//  ContentView.swift
//  Koru
//
//  Created by Jarvis on 30/05/22.
//

import SwiftUI
import SpriteKit

struct ContentView: View {
    
    var scene : SKScene {
        let scene = RopeView(size: CGSize(width: 372, height: 812))
        scene.scaleMode = .fill
        return scene
    }
    var body: some View {
        
        SpriteView(scene: scene)
                
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
