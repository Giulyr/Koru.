//
//  Rope.swift
//  Koru
//
//  Created by Jarvis on 31/05/22.
//

import Foundation
import SpriteKit

enum Emotion {
    case afraid
    case angry
    case anxious
    case disgusted
    case guilty
    case sad
    case empty
}

class Sphere : SKSpriteNode {
    
    var emotion : Emotion
    var symbol : SKSpriteNode
    var isActive : Bool = false
    var isCurrent : Bool = false
    var intrusive : IntrusiveModel?
    
    init(emotion: Emotion, intrusive: IntrusiveModel) {
        self.intrusive = intrusive
        self.emotion = emotion
        self.symbol = SKSpriteNode()
        let physics = SKPhysicsBody(circleOfRadius: 10)
        physics.isDynamic = false
        physics.affectedByGravity = false
        physics.allowsRotation = false
        physics.collisionBitMask = 0
        physics.categoryBitMask = PhysicsCategory.sphere
        physics.contactTestBitMask = PhysicsCategory.circle
        self.isActive = true
        super.init(texture: nil, color: .clear, size: CGSize(width: 25, height: 25))
        switch emotion {
        case .afraid:
            self.name = "afraid"
            self.symbol = SKSpriteNode(imageNamed: "afraid")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .angry:
            self.name = "angry"
            self.symbol = SKSpriteNode(imageNamed: "angry")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .anxious:
            self.name = "anxious"
            self.symbol = SKSpriteNode(imageNamed: "anxious")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .disgusted:
            self.name = "disgusted"
            self.symbol = SKSpriteNode(imageNamed: "disgusted")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .guilty:
            self.name = "guilty"
            self.symbol = SKSpriteNode(imageNamed: "guilty")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .sad:
            self.name = "sad"
            self.symbol = SKSpriteNode(imageNamed: "sad")
            self.symbol.size = CGSize(width: 25, height: 25)
        case .empty:
            self.name = "empty"
            self.symbol.size = CGSize(width: 25, height: 25)
        }
        self.physicsBody = physics
        self.addChild(self.symbol)
    }
    
    init() {
        self.symbol = SKSpriteNode(color: .clear , size: CGSize(width: 25, height: 25) )
        self.emotion = .empty
        let physics = SKPhysicsBody(circleOfRadius: 1)
        physics.isDynamic = false
        physics.affectedByGravity = false
        physics.allowsRotation = false
        physics.collisionBitMask = 0
        super.init(texture: nil, color: .clear, size: CGSize(width: 25, height: 25))
        self.physicsBody = physics
        self.addChild(self.symbol)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func disappear(){
        self.symbol.color = .clear
        self.symbol.texture = nil
        self.name = "empty"
        self.emotion = .empty
    }
    
    
}
