//
//  Rope.swift
//  Koru
//
//  Created by Jarvis on 31/05/22.
//

import Foundation
import SpriteKit
import SwiftUI

enum Nodes : Int{
    case noNodes
    case oneNode
    case twoNodes
    case threeNodes
    case fourNodes
    case fiveNodes
    case sixNodes
}
class Rope : SKNode {

    var parentScene : RopeView
    var spheres : [Sphere]
    var coordinates : [CGPoint] = []
    var line : SKShapeNode?
    let points : [Nodes: [CGPoint]] = [
        .noNodes : [CGPoint(x: -16, y: -260), CGPoint(x: 63, y: -265),
                    CGPoint(x: 250, y: -254),CGPoint(x: 390, y: -260)],
        .oneNode : [CGPoint(x: -16, y: -260), CGPoint(x: 63, y: -265),
                    CGPoint(x: 250, y: -254),CGPoint(x: 390, y: -260)],
        .twoNodes : [CGPoint(x: -16, y: -260), CGPoint(x: 109, y: -258),
                     CGPoint(x: 226, y: -233),CGPoint(x: 226, y: -261), CGPoint(x: 390, y: -260)],
        .threeNodes : [CGPoint(x: -16, y: -260),CGPoint(x: 106, y: -259),CGPoint(x: 223, y: -197),CGPoint(x: 168, y: -153),CGPoint(x: 131, y: -197),CGPoint(x: 246, y: -259),CGPoint(x: 390, y: -260)],
        .fourNodes : [CGPoint(x: -16, y: -260),CGPoint(x: 73, y: -262),CGPoint(x: 160, y: -229),CGPoint(x: 226, y: -250),CGPoint(x: 168, y: -162),CGPoint(x: 126, y: -235),CGPoint(x: 147, y: -277),CGPoint(x: 257, y: -277),CGPoint(x: 390, y: -260)],
        .fiveNodes : [CGPoint(x: -16, y: -260),CGPoint(x: 85, y: -334),CGPoint(x: 175, y: -260),CGPoint(x: 240, y: -292),CGPoint(x: 179, y: -200),CGPoint(x: 134, y: -253),CGPoint(x: 172, y: -315),CGPoint(x: 262, y: -305),CGPoint(x: 277, y: -228),CGPoint(x: 211, y: -161),CGPoint(x: 118, y: -200),CGPoint(x: 111, y: -285),CGPoint(x: 191, y: -337),CGPoint(x: 309, y: -302),CGPoint(x: 390, y: -260)],
        .sixNodes : [CGPoint(x: -16, y: -260),CGPoint(x: 73, y: -334),CGPoint(x: 163, y: -273),CGPoint(x: 200, y: -255),CGPoint(x: 236, y: -286),CGPoint(x: 206, y: -273),CGPoint(x: 254, y: -241),CGPoint(x: 206, y: -224),CGPoint(x: 146, y: -247),CGPoint(x: 133, y: -292),CGPoint(x: 194, y: -318),CGPoint(x: 267, y: -302),CGPoint(x: 277, y: -228),CGPoint(x: 248, y: -196),CGPoint(x: 175, y: -169),CGPoint(x: 110, y: -289),CGPoint(x: 193, y: -338),CGPoint(x: 309, y: -302),CGPoint(x: 346, y: -262),CGPoint(x: 390, y: -260)]
    ]

    
    init(spheres: [Sphere], parent: RopeView){
        self.parentScene = parent
        self.spheres = []
        super.init()
        switch spheres.count {
        case 0:
            for i in 0..<(points[.noNodes]!.count){
                let sphere = Sphere()
                sphere.position = points[.noNodes]![i]
                self.spheres.append(sphere)
                self.addChild(sphere)
            }
        case 1:
            for i in 0..<(points[.oneNode]!.count){
                if i == 1{
                    spheres[0].position = points[.oneNode]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else{
                    let sphere = Sphere()
                    sphere.position = points[.noNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        case 2:
            for i in 0..<(points[.twoNodes]!.count){
                if i == 1{
                    spheres[0].position = points[.twoNodes]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else if i == 2{
                    spheres[1].position = points[.twoNodes]![i]
                    self.spheres.append(spheres[1])
                    self.addChild(spheres[1])
                }
                else{
                    let sphere = Sphere()
                    sphere.position = points[.twoNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        case 3:
            for i in 0..<(points[.threeNodes]!.count){
                if i == 1{
                    spheres[0].position = points[.threeNodes]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else if i == 3{
                    spheres[1].position = points[.threeNodes]![i]
                    self.spheres.append(spheres[1])
                    self.addChild(spheres[1])
                }
                else if i == 5 {
                    spheres[2].position = points[.threeNodes]![i]
                    self.spheres.append(spheres[2])
                    self.addChild(spheres[2])
                } else {
                    let sphere = Sphere()
                    sphere.position = points[.threeNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        case 4:
            for i in 0..<(points[.fourNodes]!.count){
                if i == 1{
                    spheres[0].position = points[.fourNodes]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else if i == 2{
                    spheres[1].position = points[.fourNodes]![i]
                    self.spheres.append(spheres[1])
                    self.addChild(spheres[1])
                }
                else if i == 4 {
                    spheres[2].position = points[.fourNodes]![i]
                    self.spheres.append(spheres[2])
                    self.addChild(spheres[2])
                }else if i == 7 {
                    spheres[3].position = points[.fourNodes]![i]
                    self.spheres.append(spheres[3])
                    self.addChild(spheres[3])
                } else {
                    let sphere = Sphere()
                    sphere.position = points[.fourNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        case 5:
            for i in 0..<(points[.fiveNodes]!.count){
                if i == 1{
                    spheres[0].position = points[.fiveNodes]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else if i == 2{
                    spheres[1].position = points[.fiveNodes]![i]
                    self.spheres.append(spheres[1])
                    self.addChild(spheres[1])
                }
                else if i == 4 {
                    spheres[2].position = points[.fiveNodes]![i]
                    self.spheres.append(spheres[2])
                    self.addChild(spheres[2])
                }else if i == 8 {
                    spheres[3].position = points[.fiveNodes]![i]
                    self.spheres.append(spheres[3])
                    self.addChild(spheres[3])
                }else if i == 13 {
                    spheres[4].position = points[.fiveNodes]![i]
                    self.spheres.append(spheres[4])
                    self.addChild(spheres[4])
                }  else {
                    let sphere = Sphere()
                    sphere.position = points[.fiveNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        case 6:
            for i in 0..<(points[.sixNodes]!.count){
                if i == 1{
                    spheres[0].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[0])
                    self.addChild(spheres[0])
                }else if i == 2{
                    spheres[1].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[1])
                    self.addChild(spheres[1])
                }
                else if i == 4 {
                    spheres[2].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[2])
                    self.addChild(spheres[2])
                }else if i == 12 {
                    spheres[3].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[3])
                    self.addChild(spheres[3])
                }else if i == 14 {
                    spheres[4].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[4])
                    self.addChild(spheres[4])
                }else if i == 17 {
                    spheres[5].position = points[.sixNodes]![i]
                    self.spheres.append(spheres[5])
                    self.addChild(spheres[5])
                }  else {
                    let sphere = Sphere()
                    sphere.position = points[.sixNodes]![i]
                    self.spheres.append(sphere)
                    self.addChild(sphere)
                }
            }
        default:
            for i in 0..<(points[.noNodes]!.count){
                let sphere = Sphere()
                sphere.position = points[.noNodes]![i]
                self.spheres.append(sphere)
                self.addChild(spheres[i])
                if i >= 1 {
                    let joint = SKPhysicsJointSpring.joint(withBodyA: self.spheres[i].physicsBody!, bodyB: self.spheres[i-1].physicsBody!, anchorA: self.spheres[i].position, anchorB: self.spheres[i-1].position)
                    self.parentScene.physicsWorld.add(joint)
                }
            }
        }
        for sphere in self.spheres {
            self.coordinates.append(sphere.position)
        }
        self.line = SKShapeNode(splinePoints: &coordinates, count: coordinates.count)
        
        self.line!.strokeColor = UIColor.black
        self.line!.lineWidth = 2
        self.line!.zPosition = -1
        self.addChild(self.line!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func writeLine(){
        self.line!.removeFromParent()
        self.coordinates.removeAll()
        for sphere in self.spheres {
            self.coordinates.append(sphere.position)
        }
        self.line = SKShapeNode(splinePoints: &coordinates, count: coordinates.count)
        self.line!.strokeColor = UIColor.black
        self.line!.lineWidth = 2
        self.line!.zPosition = -1
        self.addChild(self.line!)
    }
    
}
