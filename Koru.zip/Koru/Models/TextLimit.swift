//
//  TextLimit.swift
//  Koru
//
//  Created by Mirko Pietro Leone on 01/06/22.
//

import SwiftUI


// MARK: TEXT FIELD LIMIT

struct TextFieldLimitModifer: ViewModifier {
    @Binding var value: String
    var length: Int

    func body(content: Content) -> some View {
        content
            .onReceive(value.publisher.collect()) {
                value = String($0.prefix(length))
            }
    }
}



struct CounterView : View {
    @Binding var text : String
    var counter : Int = 0
    
    init (text: Binding<String>){
        self._text = text
        counter = self._text.wrappedValue.count
    }
    var body: some View{
        Text("\(counter)/220")
            .font(.custom("Syne", size: 16))
            .foregroundColor(Color("CustomGray2"))
    }
 }





extension View {
    func limitInputLength(value: Binding<String>, length: Int) -> some View {
        self.modifier(TextFieldLimitModifer(value: value, length: length))
    }
}

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}
