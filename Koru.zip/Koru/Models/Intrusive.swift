//
//  Intrusive.swift
//  Koru
//
//  Created by Jarvis on 10/06/22.
//

import Foundation

class IntrusiveArray : ObservableObject {
    @Published var array : [IntrusiveModel] = []
    @Published var selectedTought : IntrusiveModel = IntrusiveModel()
}

class IntrusiveModel{
    var id : UUID?
    var context : String
    var date : Date
    var feel : String
    var thought : String
    
    init(){
        self.context = "No context"
        self.date = Date.now
        self.feel = "Angry"
        self.thought = "No thought"
    }
    
    init(id: UUID, context: String, date: Date, feel: String, thought: String){
        self.id = id
        self.context = context
        self.date = date
        self.feel = feel
        self.thought = thought
    }
}
