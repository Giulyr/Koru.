//
//  textCount .swift
//  Koru
//
//  Created by Mirko Pietro Leone on 10/06/22.
//

import SwiftUI
//
//struct textCount_: View {
//    @Binding private var text: String = "jhbjkh"
//    
//    var body: some View {
//        ZStack(){
//            AddThoughtView(text: $text)
//                .padding()
//                
//            ZStack(alignment: .topLeading) {
//                RoundedRectangle(cornerRadius: 8, style: .continuous)
//                    .fill(Color.white)
//                
//                if text.isEmpty {
//                    Text("Placeholder Text")
//                        .font(.custom("Syne", size: 16))
//                        .foregroundColor(Color(UIColor.placeholderText))
//                        .padding(.horizontal, 8)
//                        .padding(.vertical, 12)
//                }
//                
//                TextEditor(text: $text)
//                    .font(.custom("Syne", size: 16))
//                    .limitInputLength(value: $text, length: 220)
//                    .disableAutocorrection(true)
//            
//                    .padding(4)
//                
//            }
//            .frame(width: 346, height: 109)
//            .cornerRadius(15)
//        }
//    }
//}
//
////struct textCount__Previews: PreviewProvider {
////    static var previews: some View {
////        textCount_()
////    }
////}
