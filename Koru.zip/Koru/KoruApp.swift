//
//  KoruApp.swift
//  Koru
//
//  Created by Jarvis on 30/05/22.
//

import SwiftUI



enum ViewState : String {
    case mainView
    case analyzeView
    case addView
    case settings
}

class AppState: ObservableObject {
    @Published var viewState: ViewState
    @Published var isAnimating: Bool
    init() {
        self.viewState = .mainView
        self.isAnimating = false
    }
}

@main
struct KoruApp: App {
    let persistenceManager = PersistenceManager.shared
    let audio = AudioManager()

    @StateObject var appState = AppState()
    @StateObject var intrusiveArray = IntrusiveArray()
    var body: some Scene {
            WindowGroup {
                ManagerView()
                    .environmentObject(appState).environmentObject(intrusiveArray).environment(\.managedObjectContext, persistenceManager.container.viewContext).onAppear{
                        audio.playSound(fileNamed: "abb", with: "mp3", looped: true, withKey: "abb")
                        audio.changeVolume(ofPlayerWithKey: "abb", to: 0.5)
                    }
               
            }
        }
    }

